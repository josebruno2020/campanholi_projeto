Projeto para controle de estoque de uma loja em si com controle de caixa!

Versão 1.0

Feito em PHP 7.4, Boostrap, Jquery, na estrutura MVC!

No arquivo OBS.txt estão as tabelas do banco de dados que são necessárias para o funcionamento do sistema!

Como BASE_URL está definido: 'http://localhost/campanholi_projeto/public/', podendo ser alterada no arquivo environment.php;

O controle de produtos é feito tanto em unidades, quanto em kg, podendo ser vendido ou comprado em ambas medias, que o estoque automaticamente será atualizado! Apenas no cadastro de produtos, tem que informar quantos kg (se houver) tem o produto em si.
Contendo também um campo de minimos no estoque, que de acordo com a venda ou compra, o produto entra numa nova tabela, que pode ser listada no menu de "listar produtos";