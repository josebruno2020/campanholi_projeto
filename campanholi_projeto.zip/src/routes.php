<?php
global $routes;
$routes = array();

$routes['/sair'] = '/login/logout';
