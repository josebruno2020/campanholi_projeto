<?php 
class NotfoundController extends Controller {
    
    public function index() {
        $this->render('404');
    }
}